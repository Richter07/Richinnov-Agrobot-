import os
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from dotenv import load_dotenv
import openai

load_dotenv()

openai.api_key = os.getenv("OPENAI_API_KEY")
question_limits = {}
FREE_LIMIT = 10

app = Flask(__name__)

@app.route("/bot", methods=["POST"])
def bot():
    sender = request.form.get("From")
    incoming_msg = request.form.get("Body")
    response = MessagingResponse()
    msg = response.message()

    if sender not in question_limits:
        question_limits[sender] = 0

    if incoming_msg.lower().strip() == "formations":
        msg.body("Voici les formations disponibles :\n1. Maraîchage rentable\n2. Pesticides bio\n3. Entrepreneuriat agricole")
    elif incoming_msg.lower().strip() == "abonnement":
        msg.body("Abonnement illimité : 1000 FCFA/mois. Payez via Mobile Money ou PayPal.")
    elif question_limits[sender] < FREE_LIMIT:
        try:
            completion = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": incoming_msg}]
            )
            bot_reply = completion.choices[0].message.content.strip()
            msg.body(bot_reply + "\n\nAbonnez-vous pour plus de réponses !")
            question_limits[sender] += 1
        except Exception as e:
            msg.body("Erreur lors de la réponse : " + str(e))
    else:
        msg.body("Vous avez atteint la limite gratuite de 10 questions par jour. Envoyez 'abonnement' pour débloquer l'accès illimité.")

    return str(response)

if __name__ == "__main__":
    app.run(debug=True)
